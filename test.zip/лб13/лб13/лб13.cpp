﻿#include <iostream>
using namespace std;
void main()
{
    int x, y, res;
    cout << "Vvedite x=";
    cin >> x;
    cout << "Vvedite y=";
    cin >> y;
    while (x && y)
    {
        x /= 10;
        y /= 10;
    }
    if (y == 0 && x != 0)cout << "V x chislo bolseе";
    else
        if (x == 0 && y != 0)cout << "V y chislo bolse";
        else
            cout << "x and y odinakovi";
    system("pause");
}