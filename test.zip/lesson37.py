from classes import Person
# import classes

person1 = Person('John')
person1.print_info()

person2 = Person('Katy')
person2.print_info()