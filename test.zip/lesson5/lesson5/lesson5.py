#arifmet.operatory

from tkinter.tix import INTEGER


print (2+3) #slozenie 
print (2-3) #vichitanie
print (10*3) #ymnozenie
print (10/2) #delenie
print (3/2) #delenie
print (3 % 2) #delenie c ostatkom
print (30 % 2) #delenie c ostatkom
print (3 // 2) #delenie tolko chelay chact'

print (7 % 2)
print (7 // 2)

print (-5 - 3)

print (5 ** 2) #vozvedenie v stepen'
print (5 ** 3)

print (25 ** 0.5) #yznaem koren' chisla
print (100 ** 0.5)

print (2+3*4) #neskolko deistviy operatorov
print ((2+3)*4) #neskolko deistviy operatorov 

INTEGER #chelyi chisla
float #drobnye chisla

print (0.5+1.5)
print (0.5+2)
print (0.1+0.2)
