test = None #neopredelennoe znachenie
test = 123
print (test)

x, y = (1, 5) #mnozestvo peremennyix
print (x, y)

#const type bool
my_true = True
my_false = False

print (type (my_true))
print (type (my_false))

x = 5.6
print (x, type (x))
x = int (x) #privodit k type integer i ne okryglyaet chislo
print (x, type (x))

x = 5.2
print (x, type (x))
x = str (x) #privodit k type stroke
print (x, type (x))

x = 5.6
print (x, type (x))
x = bool (x) #privodit k type boolivomy (t/f)
print (x, type (x))


x = 0
print (x, type (x))
x = bool (x) #privodit k type bool (t\f)
print (x, type (x))

x = '' #toze znachimaya stroka
print (x, type (x))
x = bool (x) 
print (x, type (x))



