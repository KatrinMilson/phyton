#peremennyi

x = 1 #ravno ito prisvaivanie #int
y = 3.5 #float

my_var1 = 50
_myvar1 = 100
myVar = 30

print (type (x)) #vivedenie tipa peremennoi

print (type (y)) #vivedenie tipa peremennoi

X = 2
x = 15 #perviy x menyaetca na etot
print (x, X)

TEST = 20 #const
print (TEST)

TEST = 40
print (TEST)


