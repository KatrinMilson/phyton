from typing import re

import requests
from bs4 import BeautifulSoup
from datetime import date
url="https://www.ntv.ru/"
page = requests.get(url)
# print(page.status_code)
soup = BeautifulSoup(page.text, "html.parser")
# print(soup)

filteredNews = []
allNews = soup.findAll('h3', class_=f"symbol symbol")
print(allNews)
news_dict=[]
#
# for news in allNews:
#
# #извлекаем новость
#     content = news.find('span',class_="citem")
#
#
#     news_dict.append({
#     'url':url,
#     'content':content,
#     })
#
#
# for item in news_dict:
#     print(f'\nНовость:{item["content"]}\nКонтент:{item["url"]}\n\n\n*****************\n')