print('Hello,world!') #commentariy odnostrochnyi

'''
mnogostrochyi commentaruy
'''