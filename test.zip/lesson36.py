# class A:
#     property1 = 'Property1'
#     property2 = 'Property2'
#
#     def say_hi(self, name =''):
#         if name:
#             return 'Hi, ' + name
#         else:
#             return 'Hello, ' + self.name
#
#
# a = A()
# b = A()
# print(a.say_hi('John'))
# print(a.property1)


